# PWA Sales App

## Overview
The PWA Sales App is a full-stack application built with Node.js and React. It allows users to view sales totals for analysts based on their stock sales records stored in a MongoDB database. The application is designed as a Progressive Web App (PWA) to provide a seamless user experience across devices.

## Project Structure
The project is organized into two main directories: `backend` and `frontend`.

### Backend
- **src/app.js**: Entry point of the backend application. Sets up the Express server and connects to MongoDB.
- **src/controllers/analystController.js**: Contains the `AnalystController` class with methods to handle requests related to analysts.
- **src/models/analystModel.js**: Defines the Mongoose schema for the analysts collection.
- **src/routes/analystRoutes.js**: Exports a function to define API routes for analysts.
- **src/services/analystService.js**: Contains business logic for retrieving analyst data and calculating sales totals.
- **package.json**: Lists dependencies and scripts for the backend application.
- **README.md**: Documentation for the backend application.

### Frontend
- **public/index.html**: Main HTML file for the frontend application.
- **public/manifest.json**: Metadata for the Progressive Web App.
- **src/App.js**: Main component of the React application.
- **src/components/AnalystSales.js**: Component that fetches and displays analyst sales data.
- **src/index.js**: Entry point of the React application.
- **src/serviceWorker.js**: Service worker setup for offline capabilities.
- **package.json**: Lists dependencies and scripts for the frontend application.
- **README.md**: Documentation for the frontend application.

## Setup Instructions

### Backend
1. Navigate to the `backend` directory:
   ```
   cd backend
   ```
2. Install dependencies:
   ```
   npm install
   ```
3. Start the backend server:
   ```
   npm start
   ```
4. Ensure MongoDB is running and the connection string is correctly set in the application.

### Frontend
1. Navigate to the `frontend` directory:
   ```
   cd frontend
   ```
2. Install dependencies:
   ```
   npm install
   ```
3. Start the frontend application:
   ```
   npm start
   ```

## API Usage
The backend exposes the following API endpoint:
- **GET /analysts/:analyst_id/stock_sales_record**: Returns the `analyst_id`, `analyst_name`, and `sales_total` for the specified analyst.

## Contributing
Feel free to fork the repository and submit pull requests for any improvements or bug fixes.

## License
This project is licensed under the MIT License.