import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import './AnalystSales.css';

const AnalystSales = () => {
    const { analyst_id } = useParams();
    const [analystData, setAnalystData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        console.log(`Fetching data for analyst ID: ${analyst_id}`);
        const fetchAnalystSales = async () => {
            try {
                const response = await fetch(`http://localhost:5000/analysts/${analyst_id}/stock_sales_record`);
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const data = await response.json();
                setAnalystData(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchAnalystSales();
    }, [analyst_id]);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    return (
        <div className="container">
            <h2>Analyst Sales Data</h2>
            {analystData ? (
                <div className="analyst-details">
                    <p><strong>Analyst ID:</strong> {analystData.analyst_id}</p>
                    <p><strong>Analyst Name:</strong> {analystData.analyst_name}</p>
                    <p><strong>Sales Total:</strong> {analystData.sales_total}</p>
                </div>
            ) : (
                <p>No data available for this analyst.</p>
            )}
        </div>
    );
};

export default AnalystSales;