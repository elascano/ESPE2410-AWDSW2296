import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './AllAnalystsSales.css';

const AllAnalystsSales = () => {
  const [analystsData, setAnalystsData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAllAnalystsSales = async () => {
      try {
        const response = await fetch('http://localhost:5000/analysts');
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setAnalystsData(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAllAnalystsSales();
  }, []);

  const filteredAnalysts = analystsData.filter(analyst =>
    analyst.analyst_id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className="container">
      <h2>Analysts Sales Record</h2>
      <input
        type="text"
        placeholder="Search by analyst ID"
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
        className="search-bar"
      />
      <table className="analysts-table">
        <thead>
          <tr>
            <th>Analyst ID</th>
            <th>Analyst Name</th>
            <th>Sales Total</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          {filteredAnalysts.map(analyst => (
            <tr key={analyst.analyst_id}>
              <td>{analyst.analyst_id}</td>
              <td>{analyst.analyst_name}</td>
              <td>{analyst.sales_total}</td>
              <td>
                <Link to={`/analysts/${analyst.analyst_id}/stock_sales_record`}>View Details</Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AllAnalystsSales;