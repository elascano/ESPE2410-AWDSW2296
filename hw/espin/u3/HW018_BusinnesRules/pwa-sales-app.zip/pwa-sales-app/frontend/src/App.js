import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import AllAnalystsSales from './components/AllAnalystsSales';
import AnalystSales from './components/AnalystSales';
import './App.css';

function Home() {
  return (
    <div className="home-container">
      <h1>Welcome to the PWA Sales App</h1>
      <Link to="/analysts" className="view-link">View All Analysts Sales Data</Link>
    </div>
  );
}

function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/analysts" component={AllAnalystsSales} />
          <Route path="/analysts/:analyst_id/stock_sales_record" component={AnalystSales} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;