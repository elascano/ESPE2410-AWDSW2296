# PWA Sales App - Frontend Documentation

## Overview
This is the frontend part of the PWA Sales App, built using React. The application fetches and displays sales data for analysts from a MongoDB database through a RESTful API provided by the backend.

## Getting Started

### Prerequisites
- Node.js (version 14 or higher)
- npm (Node Package Manager)

### Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the frontend directory:
   ```
   cd pwa-sales-app/frontend
   ```
3. Install the dependencies:
   ```
   npm install
   ```

### Running the Application
To start the development server, run:
```
npm start
```
This will start the React application and open it in your default web browser. The app will be available at `http://localhost:3000`.

### Building for Production
To create a production build of the application, run:
```
npm run build
```
This will generate a `build` directory containing the optimized application.

## API Integration
The frontend communicates with the backend API to fetch analyst sales data. The main endpoint used is:
```
GET /analysts/:analyst_id/stock_sales_record
```
Replace `:analyst_id` with the actual ID of the analyst to retrieve their sales total.

## Components
- **AnalystSales**: This component fetches and displays the `analyst_id`, `analyst_name`, and `sales_total` for a specific analyst.

## Progressive Web App (PWA) Features
This application is designed as a Progressive Web App, which means it can be installed on devices and used offline. The service worker is set up to cache assets and provide offline functionality.

## Contributing
If you would like to contribute to this project, please fork the repository and submit a pull request with your changes.

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.