const mongoose = require('mongoose');

const analystSchema = new mongoose.Schema({
    analyst_id: {
        type: String,
        required: true,
        unique: true
    },
    analyst_name: {
        type: String,
        required: true
    },
    stock_symbol: {
        type: String,
        required: true
    },
    quantity: {
        type: Number,
        required: true
    },
    purchase_date: {
        type: Date,
        required: true
    },
    purchase_price: {
        type: Number,
        required: true
    },
    purchaseTransactionFee: {
        type: Number,
        required: true
    },
    sale_date: {
        type: Date,
        required: true
    },
    sale_price: {
        type: Number,
        required: true
    },
    saleTransactionFee: {
        type: Number,
        required: true
    },
    investment: {
        type: Number,
        required: true
    },
    profit: {
        type: Number,
        required: true
    }
});

const Analyst = mongoose.model('Analyst', analystSchema);

module.exports = Analyst;