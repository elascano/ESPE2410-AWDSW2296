class AnalystController {
  constructor(analystService) {
    this.analystService = analystService;
  }

  async getAllAnalystsSales(req, res) {
    try {
      const allSales = await this.analystService.getAllAnalystsSales();
      res.status(200).json(allSales);
    } catch (error) {
      res.status(500).json({ message: 'An error occurred while fetching all analysts sales data.', error: error.message });
    }
  }

  async getSalesTotal(req, res) {
    const { analyst_id } = req.params;
    try {
      const salesTotal = await this.analystService.getSalesTotal(analyst_id);
      if (salesTotal) {
        res.status(200).json(salesTotal);
      } else {
        res.status(404).json({ message: 'Analyst not found or no sales records available.' });
      }
    } catch (error) {
      res.status(500).json({ message: 'An error occurred while fetching sales total.', error: error.message });
    }
  }
}

module.exports = AnalystController;