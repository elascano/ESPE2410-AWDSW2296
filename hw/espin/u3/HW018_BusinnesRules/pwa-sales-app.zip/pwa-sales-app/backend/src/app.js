// filepath: /d:/Escritorio/Clases/Web Avanzada/PWA-Stocks/pwa-sales-app/backend/src/app.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const analystRoutes = require('./routes/analystRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(cors()); // Enable CORS

// MongoDB connection
mongoose.connect('mongodb+srv://JoseIP:1234@school.h9lw5.mongodb.net/Stocks?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/analysts', analystRoutes);

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});