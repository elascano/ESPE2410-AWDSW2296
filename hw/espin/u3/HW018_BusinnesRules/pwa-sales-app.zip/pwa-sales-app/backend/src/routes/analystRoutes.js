const express = require('express');
const AnalystController = require('../controllers/analystController');
const AnalystService = require('../services/analystService');
const AnalystModel = require('../models/analystModel');

const router = express.Router();
const analystService = new AnalystService(AnalystModel);
const analystController = new AnalystController(analystService);

router.get('/', analystController.getAllAnalystsSales.bind(analystController));
router.get('/:analyst_id/stock_sales_record', analystController.getSalesTotal.bind(analystController));

module.exports = router;