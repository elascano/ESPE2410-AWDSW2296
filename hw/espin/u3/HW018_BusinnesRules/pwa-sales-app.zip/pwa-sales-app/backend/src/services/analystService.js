class AnalystService {
    constructor(AnalystModel) {
      this.AnalystModel = AnalystModel;
    }
  
    async getAllAnalystsSales() {
      try {
        const salesRecords = await this.AnalystModel.aggregate([
          {
            $group: {
              _id: "$analyst_id",
              analyst_name: { $first: "$analyst_name" },
              sales_total: { $sum: { $subtract: [{ $multiply: ["$sale_price", "$quantity"] }, "$saleTransactionFee"] } }
            }
          }
        ]);
        return salesRecords.map(record => ({
          analyst_id: record._id,
          analyst_name: record.analyst_name,
          sales_total: record.sales_total
        }));
      } catch (error) {
        throw new Error('Error retrieving all analysts sales data: ' + error.message);
      }
    }
  
    async getSalesTotal(analystId) {
      try {
        const salesRecords = await this.AnalystModel.find({ analyst_id: analystId });
        const salesTotal = salesRecords.reduce((total, record) => {
          const saleAmount = (record.sale_price * record.quantity) - record.saleTransactionFee;
          return total + saleAmount;
        }, 0);
  
        const analystInfo = salesRecords.length > 0 ? {
          analyst_id: salesRecords[0].analyst_id,
          analyst_name: salesRecords[0].analyst_name,
          sales_total: salesTotal
        } : null;
  
        return analystInfo;
      } catch (error) {
        throw new Error('Error retrieving sales total: ' + error.message);
      }
    }
  }
  
  module.exports = AnalystService;