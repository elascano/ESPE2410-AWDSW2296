# Backend Application for PWA Sales App

## Overview
This backend application serves as the API for the PWA Sales App, providing endpoints to manage and retrieve analyst sales data from a MongoDB database.

## Technologies Used
- Node.js
- Express
- MongoDB (via Mongoose)

## Setup Instructions

### Prerequisites
- Node.js installed on your machine
- MongoDB Atlas account (or local MongoDB instance)

### Installation
1. Clone the repository:
   ```
   git clone <repository-url>
   cd pwa-sales-app/backend
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Set up your MongoDB connection string in the `app.js` file. Replace the placeholder with your actual MongoDB URI:
   ```javascript
   const mongoURI = 'mongodb+srv://<username>:<password>@school.h9lw5.mongodb.net/Stocks?retryWrites=true&w=majority';
   ```

### Running the Application
To start the server, run:
```
npm start
```
The server will be running on `http://localhost:3000`.

## API Endpoints

### Get Analyst Sales Total
- **Endpoint:** `/analysts/:analyst_id/stock_sales_record`
- **Method:** GET
- **Description:** Retrieves the sales total for a specific analyst based on their sales records.
- **Response:**
  ```json
  {
    "analyst_id": "string",
    "analyst_name": "string",
    "sales_total": "number"
  }
  ```

## Folder Structure
- `src/app.js`: Entry point of the application.
- `src/controllers/analystController.js`: Contains logic for handling analyst-related requests.
- `src/models/analystModel.js`: Defines the Mongoose schema for analysts.
- `src/routes/analystRoutes.js`: Defines the API routes for analysts.
- `src/services/analystService.js`: Contains business logic for retrieving analyst data.

## Contributing
Feel free to submit issues or pull requests for improvements or bug fixes.

## License
This project is licensed under the MIT License.