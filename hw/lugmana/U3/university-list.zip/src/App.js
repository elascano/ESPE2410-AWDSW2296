import React from 'react';
import './App.css';
import UniversitySearch from './UniversitySearch';

function App() {
  return (
    <div className="App">
      <UniversitySearch />
    </div>
  );
}

export default App;