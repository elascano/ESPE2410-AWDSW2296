import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UniversityList = ({ countryName }) => {
  const [universities, setUniversities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchUniversities = async () => {
      try {
        setLoading(true);
        const response = await axios.get(
          `http://universities.hipolabs.com/search?country=${countryName}`
        );
        setUniversities(response.data);
      } catch (err) {
        setError('Failed to fetch universities.');
      } finally {
        setLoading(false);
      }
    };

    if (countryName) {
      fetchUniversities();
    }
  }, [countryName]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div>
      <h2>Universities in {countryName}</h2>
      <table border="1" cellPadding="10" cellSpacing="0">
        <thead>
          <tr>
            <th>University Name</th>
            <th>Country</th>
            <th>Web Page</th>
            <th>Domain</th>
          </tr>
        </thead>
        <tbody>
          {universities.map((university, index) => (
            <tr key={index}>
              <td>{university.name}</td>
              <td>{university.country}</td>
              <td>
                <a href={university.web_pages[0]} target="_blank" rel="noopener noreferrer">
                  {university.web_pages[0]}
                </a>
              </td>
              <td>{university.domains.join(', ')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UniversityList;