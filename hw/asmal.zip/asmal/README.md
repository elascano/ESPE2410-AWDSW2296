Edison Lascano's Homework 
