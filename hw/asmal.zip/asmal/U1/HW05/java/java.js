function displayMessage() {
    document.getElementById("demo").innerHTML = "You clicked the button!";
}
// JavaScript Document