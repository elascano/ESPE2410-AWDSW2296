<?php
require 'vendor/autoload.php';
use MongoDB\Client;

$client = new Client("your_mongodb_connection_string");
$collection = $client->company->vehicles;

$action = $_POST['action'];

switch ($action) {
    case 'insert':
        $data = [
            'make' => $_POST['make'],
            'model' => $_POST['model'],
            'type' => $_POST['type'],
            'registration_date' => $_POST['registration_date'],
            'condition' => $_POST['condition'],
        ];
        $result = $collection->insertOne($data);
        echo json_encode(['status' => 'success', 'insertedId' => $result->getInsertedId()]);
        break;

    case 'find':
        $criteria = ['make' => $_POST['make']];
        $result = $collection->findOne($criteria);
        echo json_encode($result);
        break;

    case 'readAll':
        $vehicles = $collection->find()->toArray();
        echo json_encode($vehicles);
        break;
}
?>
