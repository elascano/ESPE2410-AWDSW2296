function handleInsert(event) {
    event.preventDefault();
    const formData = new FormData(document.getElementById("vehicleForm"));
    formData.append("action", "insert");

    fetch("php/php.php", {
        method: "POST",
        body: formData,
    })
        .then((response) => response.json())
        .then((data) => {
            alert(`Vehicle inserted with ID: ${data.insertedId}`);
            document.getElementById("vehicleForm").reset();
        });
}

