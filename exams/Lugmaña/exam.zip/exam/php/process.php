<?php
// Database connection
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'buildings_db';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $location = $_POST['location'];
    $height = $_POST['height'];
    $floors = $_POST['floors'];
    $year_built = $_POST['year_built'];

    $stmt = $conn->prepare("INSERT INTO buildings (name, location, height, floors, year_built) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('ssiii', $name, $location, $height, $floors, $year_built);

    if ($stmt->execute()) {
        echo "Building registered successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
