<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'buildings_db';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Fetch data from the database
$sql = "SELECT id, name, location, height, floors, year_built, created_at FROM buildings ORDER BY created_at DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Location</th>
                <th>Height (m)</th>
                <th>Floors</th>
                <th>Year Built</th>
                <th>Created At</th>
            </tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['location']}</td>
                <td>{$row['height']}</td>
                <td>{$row['floors']}</td>
                <td>{$row['year_built']}</td>
                <td>{$row['created_at']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>No buildings found.</p>";
}

$conn->close();
?>
