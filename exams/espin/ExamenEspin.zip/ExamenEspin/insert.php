<?php
$conn = new mysqli("bxfpmalxnon421jj2zrj-mysql.services.clever-cloud.com", "u2lad7carxvkrdiv", "yODtZEFd8My1HUHnkT9E", "bxfpmalxnon421jj2zrj");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$position = $_POST['position'];
$team = $_POST['team'];
$nationality = $_POST['nationality'];
$age = $_POST['age'];

$sql = "INSERT INTO soccer_players (name, position, team, nationality, age) 
        VALUES ('$name', '$position', '$team', '$nationality', $age)";

if ($conn->query($sql) === TRUE) {
    echo "New player added successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
