<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>See keyboards</title>
    <link href="css/estilo.css" rel="stylesheet" type="text/css">
    <link href="css/estilo_barra.css" rel="stylesheet" type="text/css">
</head>
<body>
    <?php include 'barra_navegacion.php'; ?>

    <header style="display: flex; align-items: center; padding: 10px;">
        <img src="img/" alt="Logotipo" style="max-width: 5%; margin-right: 10px;">
        <h1>Welcome to keyboards</h1>
    </header>
    <hr size="10" width="100%" noshade color="blue">

    <main>
        <section style="text-align: center;">
            <h2>Consult your keyboards</h2>
            <p>See your products.</p>

            <!-- Table of keyboards -->
            <table border="1" style="margin: 0 auto; border-collapse: collapse; width: 80%;">
                <thead style="background-color: #2F0CEC; color: white;">
                    <tr>
                        <th>Product</th>
                        <th>Tipe keyboard</th>
                        <th>Price</th>
                        <th>Comments</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Ejemplo de filas -->
                    <tr>
                        <td>Redragon</td>
                        <td>Gamer</td>
                        <td>8.5$</td>
                        <td>For Gamers</td>
                    </tr>
                    <tr>
                        <td>Mecanic keyboard</td>
                        <td>For works</td>
                        <td>19.0$</td>
                        <td>A god keyboard</td>
                    </tr>
                </tbody>
            </table>
        </section>
    </main>

    <footer style="text-align: center; padding: 10px; background-color: #f1f1f1; margin-top: 20px;">
        <p>Shop of keyboards-the best of ecuador</p>
        <p>&copy; 2024 Keyboards</p>
    </footer>
</body>
</html>
