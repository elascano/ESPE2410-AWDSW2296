<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>

<link href="css/estilo_footer.css" rel="stylesheet" type="text/css">
</head>
<body>
    <footer class="footer">
        <ul>
            <li><a href="">GitHub</a></li>
            <li><a href="">Instagram</a></li>
            <li><a href="https://youtu.be/dQw4w9WgXcQ?si=F8Jjs2DOUq64rdhu">YouTube</a></li>
            <li><a href="https://tecnologia-enlinea.com/?product=memoria-ram-ddr4-16gb-sodimm-laptop-2666mhz&v=7df67469160f">Products</a></li>
        </ul>
    </footer>
</body>
</html>
