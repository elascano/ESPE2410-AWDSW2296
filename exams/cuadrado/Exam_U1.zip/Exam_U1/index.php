<!DOCTYPE html>
<html lang="en">
<head>
    <title>Menu</title>
    <link href="css/estilo.css" rel="stylesheet" type="text/css">
    <link href="css/estilo_barra.css" rel="stylesheet" type="text/css">
    <link href="css/estilo_footer.css" rel="stylesheet" type="text/css">
</head>
<body>
	<?php include 'barra_navegacion.php'; ?>


    <p><strong>Client Name:</strong> Its a index.</p>



    <hr size="10" width="100%" noshade color="#2F0CEC">

    <h1>Information</h1>
    <p>
</body>
</html>
