<?php
include 'db_connection.php';

if (isset($_POST['save'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $total = $_POST['total'];
    $quantity = $_POST['quantity'];

    $sql = "INSERT INTO toys (id, name, day, month, year, total, quantity) VALUES ('$id', '$name', '$day', '$month', '$year', '$total', '$quantity')";
    if ($conn->query($sql) === TRUE) {
        echo "Record inserted successfully";
    } else {
        echo "Error: " . $conn->error;
    }
}

if (isset($_POST['edit'])) {
    header("Location: edit.html");
    exit();
}

if (isset($_POST['delete'])) {
    $name = $_POST['name'];
    $sql = "DELETE FROM toys WHERE name='$name'";
    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
