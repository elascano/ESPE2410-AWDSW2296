import express from 'express';
const app = express();
const port = 3002;
app.get('/', (req, res) => {
    res.send('Welcome Andres to server\n');
});
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});

