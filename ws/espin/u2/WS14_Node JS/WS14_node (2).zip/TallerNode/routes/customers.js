const express = require('express');
const router = express.Router();
const customer=require('../models/customer');


router.get('/customers',async (req, res) => {
    try{
        const customers=await customer.find();
        res.json(customers);
    }catch(err){
        res.json({message:err});
    }
});

router.get('/customer/:id',async (req, res) => {
    try{
        const customers=await customer.findById(req.params.id);
        res.json(customers);
    }catch(err){
        res.json({message:err});
    }
});

router.post('/customer',async (req, res) => {
    const customers=new customer({
        id:req.body.id,
        name:req.body.name,
        age:req.body.age,
        moneySpent:req.body.moneySpent
    });
    try{
        const savedCustomer=await customers.save();
        res.json(savedCustomer);
    }catch(err){
        res.json({message:err});
    }
});

module.exports=router;