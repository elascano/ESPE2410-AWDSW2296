const customers = require('../models/customer');

exports.getCustomers = (req, res) => {
    customers.find({}, (err, customers) => {
        if (err) {
            res.send(err);
        }
        res.json(customers);
    });
}

exports.getCustomer = (req, res) => {
    customers.findById(req.params.id, (err, customer) => {
        if (err) {
            res.send(err);
        }
        res.json(customer);
    });
}

exports.createCustomer = (req, res) => {
    const customer = new customers(req.body);
    customer.save((err) => {
        if (err) {
            res.send(err);
        }
        res.json({ message: 'Customer created!' });
    });
}