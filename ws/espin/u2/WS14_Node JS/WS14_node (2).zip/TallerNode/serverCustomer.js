const express = require('express');
const conectDB = require('./config/db');
const dotenv = require('dotenv');

dotenv.config();
conectDB();

const app = express();
app.use(express.json());

app.use('/computerstore', require('./routes/customers'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Andres's Computers Store Server is running on port ${PORT}`));