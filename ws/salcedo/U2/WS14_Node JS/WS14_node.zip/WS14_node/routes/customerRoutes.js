const express = require('express');
const Customer = require('../models/customer'); // Modelo de cliente
const router = express.Router();

// Obtener todos los clientes
router.get('/customers', async (req, res) => {
    try {
        const customers = await Customer.find(); // Encuentra todos los documentos
        res.json(customers);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


async function getCustomer(req, res, next) {
    let customer;
    try {
        customer = await Customer.findOne({ id: parseInt(req.params.id) }); 
        if (customer == null) {
            return res.status(404).json({ message: 'Customer not found' });
        }
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }

    res.customer = customer; 
    next();
}

router.get('/customers/:id', getCustomer, (req, res) => {
    res.json(res.customer); 
});

//Create/Insert one customer
router.post('/customer', async (req, res) => {
    const customerObject = new customer({
        id: req.body.id,
        name: req.body.name,
        age: req.body.age,
        moneySpent: req.body.moneySpent
    });

    try{
        const customerToSave = await customerObject.save();
        res.status(200).json(customerToSave);
    }
    catch(error){
        res.status(500).json({ message: error.message});
    }
});

module.exports = router;
