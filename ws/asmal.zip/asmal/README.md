Edison Lascano's assignments
