using GestionProyectos;
using Microsoft.AspNetCore.Builder;
namespace xUnit
{
    public class ProductoControllerTest
    {
        [Fact]
        public void Test1()
        {
            //Configurar 
            var producto = new Producto { Id=1, Nombre = "prueba", Precio = -10 };

            //Validar
            Assert.True(producto.Precio >= 0, "El precio no puede ser negativo");
        }



        [Fact]
        public void Should_ThrowException_When_EnvironmentVariableIsMissing()
        {
            // Arrange
            Environment.SetEnvironmentVariable("DB_SERVER", null);

            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() =>
            {
                var dbServer = Environment.GetEnvironmentVariable("DB_SERVER")
                    ?? throw new InvalidOperationException("DB_SERVER is not set in .env file");
            });

            Assert.Equal("DB_SERVER is not set in .env file", exception.Message);
        }

        [Fact]
        public void Should_ConstructConnectionString_WithValidEnvironmentVariables()
        {
            // Arrange
            Environment.SetEnvironmentVariable("DB_SERVER", "localhost");
            Environment.SetEnvironmentVariable("DB_DATABASE", "TestDb");
            Environment.SetEnvironmentVariable("DB_USER", "test_user");
            Environment.SetEnvironmentVariable("DB_PASSWORD", "password");

            // Act
            var dbServer = Environment.GetEnvironmentVariable("DB_SERVER")
                ?? throw new InvalidOperationException("DB_SERVER is not set in .env file");
            var dbDatabase = Environment.GetEnvironmentVariable("DB_DATABASE")
                ?? throw new InvalidOperationException("DB_DATABASE is not set in .env file");
            var dbUser = Environment.GetEnvironmentVariable("DB_USER")
                ?? throw new InvalidOperationException("DB_USER is not set in .env file");
            var dbPassword = Environment.GetEnvironmentVariable("DB_PASSWORD")
                ?? throw new InvalidOperationException("DB_PASSWORD is not set in .env file");

            var connectionString = $"Server={dbServer};" +
                                   $"Database={dbDatabase};" +
                                   $"User ID={dbUser};" +
                                   $"Password={dbPassword};" +
                                   $"TrustServerCertificate=true; MultipleActiveResultSets=true";

            // Assert
            Assert.Equal("Server=localhost;Database=TestDb;User ID=test_user;Password=password;TrustServerCertificate=true; MultipleActiveResultSets=true", connectionString);
        }


    }
}
