using GestionProyectos;
using Microsoft.EntityFrameworkCore;
using DotNetEnv;

var builder = WebApplication.CreateBuilder(args);

// Cargar variables desde el archivo .env
Env.Load();

// Verificar variables de entorno y construir la cadena de conexi�n
try
{
    var dbServer = Environment.GetEnvironmentVariable("DB_SERVER")
        ?? throw new InvalidOperationException("DB_SERVER is not set in .env file");
    var dbDatabase = Environment.GetEnvironmentVariable("DB_DATABASE")
        ?? throw new InvalidOperationException("DB_DATABASE is not set in .env file");
    var dbUser = Environment.GetEnvironmentVariable("DB_USER")
        ?? throw new InvalidOperationException("DB_USER is not set in .env file");
    var dbPassword = Environment.GetEnvironmentVariable("DB_PASSWORD")
        ?? throw new InvalidOperationException("DB_PASSWORD is not set in .env file");

    var connectionString = $"Server={dbServer};" +
                           $"Database={dbDatabase};" +
                           $"User ID={dbUser};" +
                           $"Password={dbPassword};" +
                           $"TrustServerCertificate=true; MultipleActiveResultSets=true";
    builder.Configuration["ConnectionStrings:DefaultConnection"] = connectionString;
}
catch (Exception ex)
{
    Console.WriteLine($"Error during environment configuration: {ex.Message}");
    throw;
}

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AppDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
await app.RunAsync();
