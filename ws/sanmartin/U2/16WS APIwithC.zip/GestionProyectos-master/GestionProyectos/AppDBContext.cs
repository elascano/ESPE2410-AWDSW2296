﻿using System.Text.Json.Serialization;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace GestionProyectos
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options) { }

        public DbSet<Producto> Productos { get; set; }
        public DbSet<Categoria> Categorias { get; set; }
    }

    public class Producto
    {
        public required  int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Descripcion { get; set; }
        [JsonRequired]  public decimal Precio { get; set; }
        public int? Stock { get; set; }

        // Relación con categorías
        public ICollection<Categoria> Categorias { get; set; } = new List<Categoria>();
    }

    public class Categoria
    {
        public required  int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Descripcion { get; set; }

    }




}
