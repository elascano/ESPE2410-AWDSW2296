﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace GestionProyectos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriaController : ControllerBase
    {
        private readonly AppDBContext _appDbContext;

        public CategoriaController(AppDBContext appDBContext)
        {
            _appDbContext = appDBContext;
        }

        // Obtener todas las categorías
        [HttpGet]
        public async Task<IActionResult> GetCategorias()
        {
            var categorias = await _appDbContext.Categorias.ToListAsync();
            return Ok(categorias);
        }

        // Crear una categoría
        [HttpPost]
        public async Task<IActionResult> CreateCategoria(Categoria categoria)
        {
            if (string.IsNullOrEmpty(categoria.Nombre))
            {
                return BadRequest("El nombre de la categoría es obligatorio");
            }

            _appDbContext.Categorias.Add(categoria);
            await _appDbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCategorias), new { id = categoria.Id }, categoria);
        }

        // Editar una categoría
        [HttpPut("{id}")]
        public async Task<IActionResult> EditarCategoria(int id, Categoria categoria)
        {
            if (id != categoria.Id)
            {
                return BadRequest("El ID de la categoría no coincide");
            }

            var categoriaExistente = await _appDbContext.Categorias.FindAsync(id);

            if (categoriaExistente == null)
            {
                return NotFound("La categoría no existe");
            }

            categoriaExistente.Nombre = categoria.Nombre;
            categoriaExistente.Descripcion = categoria.Descripcion;

            _appDbContext.Categorias.Update(categoriaExistente);
            await _appDbContext.SaveChangesAsync();

            return Ok(categoriaExistente);
        }

        // Eliminar una categoría
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarCategoria(int id)
        {
            var categoria = await _appDbContext.Categorias.FindAsync(id);

            if (categoria == null)
            {
                return NotFound("La categoría no existe");
            }

            _appDbContext.Categorias.Remove(categoria);
            await _appDbContext.SaveChangesAsync();

            return Ok(new { message = $"Categoría con ID {id} eliminada correctamente" });
        }
    }
}
