﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace GestionProyectos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly AppDBContext _appDbContext;

        public ProductoController(AppDBContext appDBContext)
        {
            _appDbContext = appDBContext;
        }

        // Obtener todos los productos con sus categorías
        [HttpGet]
        public async Task<IActionResult> GetProductos()
        {
            var productos = await _appDbContext.Productos
                .Include(p => p.Categorias)
                .ToListAsync();
            return Ok(productos);
        }

        // Crear un producto con categorías
        [HttpPost]
        public async Task<IActionResult> CreateProducto(Producto producto)
        {
            if (producto.Precio < 0)
            {
                return BadRequest("El precio del producto no puede ser negativo");
            }

            // Obtener los IDs de las categorías proporcionadas
            var categoriasIds = producto.Categorias.Select(c => c.Id).ToList();

            // Filtrar las categorías existentes en la base de datos
            var categoriasExistentes = await _appDbContext.Categorias
                .Where(c => categoriasIds.Contains(c.Id))
                .ToListAsync();

            // Validar las categorías faltantes
            var idsFaltantes = categoriasIds
                .Except(categoriasExistentes.Select(c => c.Id))
                .ToList();

            if (idsFaltantes.Any())
            {
                return BadRequest($"Las categorías con ID {string.Join(", ", idsFaltantes)} no existen");
            }

            // Asignar las categorías existentes al producto
            producto.Categorias = categoriasExistentes;

            // Guardar el producto en la base de datos
            _appDbContext.Productos.Add(producto);
            await _appDbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetProductos), new { id = producto.Id }, producto);

        }

        // Editar un producto y sus categorías asociadas
        [HttpPut("{id}")]
        public async Task<IActionResult> EditarProducto(int id, Producto producto)
        {
            if (id != producto.Id)
            {
                return BadRequest("El ID del producto no coincide");
            }

            if (producto.Precio < 0)
            {
                return BadRequest("El precio del producto no puede ser negativo");
            }

            var productoExistente = await _appDbContext.Productos
                .Include(p => p.Categorias)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (productoExistente == null)
            {
                return NotFound("El producto no existe");
            }

            productoExistente.Nombre = producto.Nombre;
            productoExistente.Descripcion = producto.Descripcion;
            productoExistente.Precio = producto.Precio;
            productoExistente.Stock = producto.Stock;

            // Actualizar categorías asociadas usando LINQ
            var categoriasIds = producto.Categorias.Select(c => c.Id).ToList();

            // Obtener las categorías existentes que coincidan con los IDs proporcionados
            var categoriasExistentes = await _appDbContext.Categorias
                .Where(categoria => categoriasIds.Contains(categoria.Id))
                .ToListAsync();

            // Verificar si faltan categorías
            var idsFaltantes = categoriasIds
                .Except(categoriasExistentes.Select(c => c.Id))
                .ToList();

            if (idsFaltantes.Count > 0)
            {
                return BadRequest($"Las categorías con ID {string.Join(", ", idsFaltantes)} no existen");
            }

            // Asignar las categorías existentes al producto
            productoExistente.Categorias = categoriasExistentes;

            _appDbContext.Productos.Update(productoExistente);
            await _appDbContext.SaveChangesAsync();

            return Ok(productoExistente);

        }

        // Eliminar un producto
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarProducto(int id)
        {
            var producto = await _appDbContext.Productos
                .Include(p => p.Categorias)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (producto == null)
            {
                return NotFound("El producto no existe");
            }

            _appDbContext.Productos.Remove(producto);
            await _appDbContext.SaveChangesAsync();

            return Ok(new { message = $"Producto con ID {id} eliminado correctamente" });
        }
    }
}
