﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GestionProyectos.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        // Constantes para los tipos de datos
        private const string StringMaxType = "nvarchar(max)";
        private const string DecimalType = "decimal(18,2)";
        private const string IntType = "int";

        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Productos",
                columns: table => new
                {
                    Id = table.Column<int>(type: IntType, nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: StringMaxType, nullable: true),
                    Descripcion = table.Column<string>(type: StringMaxType, nullable: true),
                    Precio = table.Column<decimal>(type: DecimalType, nullable: false),
                    Stock = table.Column<int>(type: IntType, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Productos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Categorias",
                columns: table => new
                {
                    Id = table.Column<int>(type: IntType, nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: StringMaxType, nullable: true),
                    Descripcion = table.Column<string>(type: StringMaxType, nullable: true),
                    ProductoId = table.Column<int>(type: IntType, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categorias", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Categorias_Productos_ProductoId",
                        column: x => x.ProductoId,
                        principalTable: "Productos",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Categorias_ProductoId",
                table: "Categorias",
                column: "ProductoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Categorias");

            migrationBuilder.DropTable(
                name: "Productos");
        }
    }
}
