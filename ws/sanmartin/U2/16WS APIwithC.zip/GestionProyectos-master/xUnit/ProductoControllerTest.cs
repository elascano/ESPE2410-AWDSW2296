namespace xUnit
{
    public class ProductoControllerTest
    {
        [Fact]
        public void Test1()
        {
            //Configurar
            var producto = new ProductoControllerTest { Nombre = "Pueba", Precio = -10 }
            Assert.True(producto)
        }
    }
}