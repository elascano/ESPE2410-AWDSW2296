import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:3003';


const CarList = () => {
  const [cars, setCars] = useState([]);
  const [selectedCar, setSelectedCar] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCars();
  }, []);

  const fetchCars = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/plans`);
      const data = await response.json();
      setCars(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching cars:', error);
      setLoading(false);
    }
  };

  const fetchCarDetails = async (id) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/plans/${id}`);
      const data = await response.json();
      setSelectedCar(data);
    } catch (error) {
      console.error('Error fetching car details:', error);
    }
  };

  if (loading) {
    return <p>Loading cars...</p>;
  }

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Car List</h2>
      <table className="table table-striped table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Model</th>
            <th>Color</th>
            <th>Price</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {cars.map((car) => (
            <tr key={car.id}>
              <td>{car.id}</td>
              <td>{car.model}</td>
              <td>{car.color}</td>
              <td>${car.price}</td>
              <td>
                <button className="btn btn-info" onClick={() => fetchCarDetails(car.id)}>
                  View Details
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {selectedCar && (
        <div className="mt-4 p-3 border">
          <h3>Car Details</h3>
          <p><strong>Model:</strong> {selectedCar.model}</p>
          <p><strong>Color:</strong> {selectedCar.color}</p>
          <p><strong>Price:</strong> ${selectedCar.price}</p>
          <h4>Payment Plans</h4>
          <ul>
            <li>12 months: ${selectedCar.fees.twelveMonths} per month</li>
            <li>24 months: ${selectedCar.fees.twentyFourMonths} per month</li>
            <li>60 months: ${selectedCar.fees.sixtyMonths} per month</li>
            <li>120 months: ${selectedCar.fees.oneHundredTwentyMonths} per month</li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default CarList;
