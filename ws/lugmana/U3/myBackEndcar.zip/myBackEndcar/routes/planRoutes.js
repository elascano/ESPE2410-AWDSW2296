const express = require('express');
const router = express.Router();
const planController = require('../controllers/planController');

// Obtener todos los coches
router.get('/', planController.getAllCars);

// Obtener coche por modelo y calcular las cuotas
router.get('/:id', planController.getCarByModel);

router.post('/create', planController.createCar);

module.exports = router;
