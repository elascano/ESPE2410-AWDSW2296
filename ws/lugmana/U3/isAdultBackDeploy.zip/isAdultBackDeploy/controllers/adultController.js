const pool = require('../config/db');

const adultController = {
  // Obtiene un usuario por su ID y verifica si es mayor de edad
  getUserById: async (req, res) => {
    try {
      const { id } = req.params;

      // Consultar la base de datos
      const [users] = await pool.query(
        'SELECT nombre, dia_nacimiento, mes_nacimiento, anio_nacimiento FROM usuario_edad WHERE id = ?',
        [id]
      );

      if (users.length === 0) {
        return res.status(404).json({ message: 'Usuario no encontrado' });
      }

      const { nombre, dia_nacimiento, mes_nacimiento, anio_nacimiento } = users[0];

      // Obtener la fecha actual
      const hoy = new Date();
      const anioActual = hoy.getFullYear();
      const mesActual = hoy.getMonth() + 1; // Los meses en JS van de 0 a 11
      const diaActual = hoy.getDate();

      // Calcular la edad
      let edad = anioActual - anio_nacimiento;
      if (mes_nacimiento > mesActual || (mes_nacimiento === mesActual && dia_nacimiento > diaActual)) {
        edad--;
      }

      // Determinar si es mayor de edad
      const estado = edad >= 18 ? 'Es mayor de edad' : 'Es menor de edad';

      res.json({ nombre, edad, estado });
    } catch (error) {
      console.error('Error al verificar la edad:', error);
      res.status(500).json({ message: 'Error en el servidor', error: error.message });
    }
  },

  // Crea un usuario con su fecha de nacimiento
  createUser: async (req, res) => {
    try {
      const { nombre, dia_nacimiento, mes_nacimiento, anio_nacimiento } = req.body;

      await pool.query(
        'INSERT INTO usuario_edad (nombre, dia_nacimiento, mes_nacimiento, anio_nacimiento) VALUES (?, ?, ?, ?)',
        [nombre, dia_nacimiento, mes_nacimiento, anio_nacimiento]
      );

      res.json({ message: 'Usuario creado correctamente', usuario: { nombre, dia_nacimiento, mes_nacimiento, anio_nacimiento } });
    } catch (error) {
      console.error('Error al crear el usuario:', error);
      res.status(500).json({ message: 'Error en el servidor', error: error.message });
    }
  },

  // Obtiene todos los usuarios registrados
  getAllUsers: async (req, res) => {
    try {
      const [users] = await pool.query('SELECT * FROM usuario_edad');
      res.json(users);
    } catch (error) {
      console.error('Error al obtener los usuarios:', error);
      res.status(500).json({ message: 'Error en el servidor', error: error.message });
    }
  },

  // Actualiza los datos de un usuario por su ID
  updateUser: async (req, res) => {
    try {
      const { id } = req.params;
      const { nombre, dia_nacimiento, mes_nacimiento, anio_nacimiento } = req.body;

      // Actualizar usuario en la base de datos
      const [result] = await pool.query(
        'UPDATE usuario_edad SET nombre = ?, dia_nacimiento = ?, mes_nacimiento = ?, anio_nacimiento = ? WHERE id = ?',
        [nombre, dia_nacimiento, mes_nacimiento, anio_nacimiento, id]
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Usuario no encontrado' });
      }

      res.json({ message: 'Usuario actualizado correctamente' });
    } catch (error) {
      console.error('Error al actualizar el usuario:', error);
      res.status(500).json({ message: 'Error en el servidor', error: error.message });
    }
  },

  // Elimina un usuario por su ID
  deleteUser: async (req, res) => {
    try {
      const { id } = req.params;

      // Eliminar usuario de la base de datos
      const [result] = await pool.query('DELETE FROM usuario_edad WHERE id = ?', [id]);

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Usuario no encontrado' });
      }

      res.json({ message: 'Usuario eliminado correctamente' });
    } catch (error) {
      console.error('Error al eliminar el usuario:', error);
      res.status(500).json({ message: 'Error en el servidor', error: error.message });
    }
  },
};

module.exports = adultController;
