const pool = require('../config/db');

// Función para calcular las cuotas mensuales
const calcularCuotas = (precio, meses, tasaInteresAnual) => {
  const tasaInteresMensual = tasaInteresAnual / 12 / 100;
  const cuotaMensual = (precio * tasaInteresMensual) / (1 - Math.pow(1 + tasaInteresMensual, -meses));
  return cuotaMensual.toFixed(2);
};

const planController = {
  // Obtiene todos los coches de la tabla "car"
  getAllCars: async (req, res) => {
    try {
      const [cars] = await pool.query('SELECT * FROM car');
      res.json(cars);
    } catch (error) {
      console.error('Error al obtener los coches:', error);
      res.status(500).json({ message: 'Error en el servidor', error: error.message });
    }
  },


  createCar: async (req, res) => {  
    try {
      const { model, price, color } = req.body;
      const [cars] = await pool.query('INSERT INTO car (model, price, color) VALUES (?, ?, ?)', [model, price, color]);
      res.json({ message: 'Coche creado correctamente', car: { model, price, color } });
    } catch (error) {
      console.error('Error al crear el coche:', error);
      res.status(500).json({ message: 'Error en el servidor', error: error.message });
    }
  },

  // Obtiene un coche por su modelo y calcula las cuotas para diferentes períodos
  getCarByModel: async (req, res) => {
    try {
      const { id } = req.params;
      const [cars] = await pool.query('SELECT * FROM car WHERE id = ?', [id]);

      if (cars.length === 0) {
        return res.status(404).json({ message: 'Coche no encontrado' });
      }

      const car = cars[0];
      const tasaInteresAnual = 5; // Tasa de interés anual del 5%
      const fees = {
        twelveMonths: calcularCuotas(car.price, 12, tasaInteresAnual),
        twentyFourMonths: calcularCuotas(car.price, 24, tasaInteresAnual),
        sixtyMonths: calcularCuotas(car.price, 60, tasaInteresAnual),
        oneHundredTwentyMonths: calcularCuotas(car.price, 120, tasaInteresAnual),
      };

      res.json({
        ...car,
        fees,
      });
    } catch (error) {
      console.error('Error al obtener el coche:', error);
      res.status(500).json({ message: 'Error en el servidor', error: error.message });
    }
  },
};

module.exports = planController;
