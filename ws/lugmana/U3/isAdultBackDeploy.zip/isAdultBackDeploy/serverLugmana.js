const express = require('express');
const cors = require('cors');
const userRoutes = require('./routes/userRoutes');
const microphoneRoutes = require('./routes/microphoneRoutes'); 
const stockRoutes = require('./routes/stockRoutes'); 
const planRoutes = require('./routes/planRoutes'); 
const adulRoutes = require('./routes/adultRoutes');



const app = express();

// Configuración de CORS
app.use(
  cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);

app.use(express.json());


app.use('/api/users', userRoutes);
app.use('/api/microphones', microphoneRoutes); 
app.use('/api/vinil', userRoutes);
app.use('/api/stocks/purchase', stockRoutes);
app.use('/api/stocks', stockRoutes);
app.use('/api/plans', planRoutes);

app.use('/api/adult', adulRoutes);


const PORT = process.env.PORT || 3010;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});

module.exports = app;
