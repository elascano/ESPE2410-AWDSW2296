const express = require('express');
const router = express.Router();
const adultController = require('../controllers/adultController');

// Obtener todos los usuarios
router.get('/', adultController.getAllUsers);

// Obtener usuario por ID 
router.get('/user/:id', adultController.getUserById);

// Crear un nuevo usuario
router.post('/create', adultController.createUser);

// Actualizar un usuario por ID
router.put('/update/:id', adultController.updateUser);

// Eliminar un usuario por ID
router.delete('/delete/:id', adultController.deleteUser);

module.exports = router;
